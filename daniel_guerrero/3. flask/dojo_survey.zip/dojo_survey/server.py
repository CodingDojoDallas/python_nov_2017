from flask import Flask, render_template, redirect, request

app = Flask(__name__)

app.secret_key = "my_super_secret_key"


@app.route('/')
def index():
    return render_template('index.html')
#==================================================


@app.route('/result', methods=['POST'])
def result():
    content = {
        "name": request.form['name'],
        "location": request.form['location'],
        "fav": request.form['fav'],
        "comment": request.form['comment']
    }

    return render_template('result.html', content=content)


app.run(debug=True)
